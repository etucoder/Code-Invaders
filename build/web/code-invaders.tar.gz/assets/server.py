import asyncio
import json

import websockets


#adasddsasdasdsasdsasdasdsasdwdsdsasdasdadsdassdaswcxzxcdsasdxzxcdaddasdasdwswswssswdwadddwsaswdwsasddsaaddsdasdadwdsawsdddswaawsddswaawsdwdwddwdadsassasaswdwdasswssswswsasdwswadsdsasddsasdasdasdsawdawdwddsasaswddwsaaswddwsaaaswdwdwwswaddwddsdsaadwsdawsdwsddadwsasdwsadadadadadadadwsdwsassssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssdawswswswdaadwswswswswsadadwswswsasdadsasdasdwsaswswswsaadswaadadaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadadadadwswswswswswswswswsdadwsaswsswsadwsasdwsadswsaa


PORT = 8765
PLAYER_STARTS = {1: "486,400", 2: "800,400"}
connected_nodes = {}
match_telemetry = {"p1": {'x' : 486, 'y': 400,"level":1,'in_shop': False}
                   , "p2": {'x' : 800, 'y' : 400,'level' : 1, 'in_shop' : False}}
connection_lock = asyncio.Lock() 
 

async def route_security_packets(websocket):
    global match_telemetry
    async with connection_lock:
        player_id = next((slot for slot in (1, 2) if slot not in connected_nodes), None)
        if player_id is not None:
            connected_nodes[player_id] = websocket
        else:
            await websocket.close(reason="Maximum player count")
            return
    try:
        await websocket.send(json.dumps({"player_id": player_id}))
        
        async for packet in websocket:
            try:
                incoming_payload = json.loads(packet)
                

                if incoming_payload.get("type") == "laser_fired":
            
                    target_id = 2 if player_id == 1 else 1
                    if target_id in connected_nodes:
                
                        await connected_nodes[target_id].send(json.dumps(incoming_payload))
                    continue 
                else:
                    print(incoming_payload.get("type"))
           
                x = int(incoming_payload["x"])
                y = int(incoming_payload["y"])
                
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                continue
                
            match_telemetry[f"p{player_id}"] = f"{x},{y}"
            broadcast_string = json.dumps(match_telemetry)
            recipients = tuple(connected_nodes.values())
            await asyncio.gather(
                *(node.send(broadcast_string) for node in recipients),
                return_exceptions=True,
                )
    except websockets.exceptions.ConnectionClosed:
        print(f"Connection closed for player {player_id}")
    finally:
        async with connection_lock:
            if connected_nodes.get(player_id) is websocket:
                del connected_nodes[player_id]
                match_telemetry[f"p{player_id}"] = PLAYER_STARTS[player_id]

async def main():
    print(f"WebSocket server listening on port {PORT}")
    async with websockets.serve(
        route_security_packets, "0.0.0.0", PORT, ping_interval=20, ping_timeout=20
    ):
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main(), loop_factory=asyncio.SelectorEventLoop)
